
# FITBIT ANALYSIS REPORT

## Sample Overview
- Users: 33
- Days analyzed: 220
- Period: 2016-04-12 to 2016-05-12

## Key Findings
| Metric               | Value               |
|----------------------|---------------------|
| Avg. Daily Steps     | 7472.7 � 4552.4 |
| Total Active Minutes | 4,338.0 |
| Calories/Day         | 2317.1 � 689.1 |

![Visual Summary](final_visuals.png)
